﻿
import * as THREE from "./libs/three.module.js";
import {
  World,
  SAPBroadphase,
  Body,
  Plane,
  Box,
  Vec3,
  Quaternion,
  RaycastVehicle,
  Trimesh
} from "./libs/cannon-es.js";

const TRACK = {
  laps: 3,
  width: 14,
  spline: [
    [0, 0, 100],
    [80, 0, 80],
    [100, 0, 0],
    [80, 0, -80],
    [0, 0, -100],
    [-80, 0, -80],
    [-100, 0, 0],
    [-80, 0, 80]
  ],
  checkpoints: [
    { position: [0, 0, 100], forward: [1, 0, 0], width: 14 },
    { position: [100, 0, 0], forward: [0, 0, -1], width: 14 },
    { position: [0, 0, -100], forward: [-1, 0, 0], width: 14 },
    { position: [-100, 0, 0], forward: [0, 0, 1], width: 14 }
  ],
  startPosition: [0, 0.6, 95],
  startRotation: Math.PI / 2
};

const CAR = {
  mass: 1500,
  maxEngineForce: 3000,
  maxBrakeForce: 150,
  maxSteerAngle: 0.5,
  wheelRadius: 0.3,
  suspensionStiffness: 40,
  suspensionDamping: 3,
  suspensionRestLength: 0.3,
  frictionSlip: 2,
  rollInfluence: 0.05,
  cameraFollow: { distance: 8, height: 4, lookAhead: 4 }
};

const KEYSET = new Set(["KeyW", "KeyA", "KeyS", "KeyD", "KeyQ", "KeyR", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space"]);
const keys = new Set();

window.addEventListener("keydown", (e) => {
  if (KEYSET.has(e.code)) e.preventDefault();
  keys.add(e.code);
});
window.addEventListener("keyup", (e) => {
  if (KEYSET.has(e.code)) e.preventDefault();
  keys.delete(e.code);
});

function inputState() {
  const left = keys.has("KeyA") || keys.has("ArrowLeft");
  const right = keys.has("KeyD") || keys.has("ArrowRight");
  return {
    accelerate: keys.has("KeyW") || keys.has("ArrowUp"),
    brake: keys.has("KeyS") || keys.has("ArrowDown"),
    steer: left && !right ? -1 : right && !left ? 1 : 0,
    handbrake: keys.has("Space"),
    boost: keys.has("KeyQ"),
    resetCar: keys.has("KeyR")
  };
}

function formatMs(ms) {
  const m = Math.floor(ms / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const mm = Math.floor(ms % 1000);
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}.${String(mm).padStart(3, "0")}`;
}

class EngineAudio {
  constructor() {
    this.ctx = null;
    this.started = false;
    this.lowpass = null;
    this.gain = null;
    this.osc1 = null;
    this.osc2 = null;
    this.noise = null;
    this.skidFilter = null;
    this.skidGain = null;
    this.skidSource = null;
    this.skidOn = false;
  }

  initGraph() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.lowpass = this.ctx.createBiquadFilter();
    this.lowpass.type = "lowpass";
    this.lowpass.frequency.value = 800;
    this.gain = this.ctx.createGain();
    this.gain.gain.value = 0;
    this.osc1 = this.ctx.createOscillator();
    this.osc2 = this.ctx.createOscillator();
    this.osc1.type = "sawtooth";
    this.osc2.type = "sawtooth";
    this.osc1.frequency.value = 30;
    this.osc2.frequency.value = 60;
    const blend = this.ctx.createGain();
    blend.gain.value = 0.4;
    this.osc1.connect(this.lowpass);
    this.osc2.connect(blend);
    blend.connect(this.lowpass);
    this.lowpass.connect(this.gain);
    this.gain.connect(this.ctx.destination);

    const rate = this.ctx.sampleRate;
    this.noise = this.ctx.createBuffer(1, rate, rate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < rate; i++) d[i] = Math.random() * 2 - 1;
    this.skidFilter = this.ctx.createBiquadFilter();
    this.skidFilter.type = "bandpass";
    this.skidFilter.frequency.value = 2000;
    this.skidGain = this.ctx.createGain();
    this.skidGain.gain.value = 0;
    this.skidFilter.connect(this.skidGain);
    this.skidGain.connect(this.ctx.destination);
  }

  async start() {
    if (this.started) return;
    this.initGraph();
    if (!this.ctx) return;
    this.started = true;
    await this.ctx.resume();
    this.osc1.start();
    this.osc2.start();
    this.gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
  }

  update(speed, accel, handbrake) {
    if (!this.started) return;
    const t = this.ctx.currentTime;
    const target = 30 + Math.min(Math.abs(speed), 200) * 0.4;
    this.osc1.frequency.setTargetAtTime(target, t, 0.1);
    this.osc2.frequency.setTargetAtTime(target * 2, t, 0.1);
    const maxVol = accel ? 0.12 : 0.06;
    const level = 0.04 + (maxVol - 0.04) * Math.min(Math.abs(speed) / 100, 1);
    this.gain.gain.setTargetAtTime(level, t, 0.1);
    this.lowpass.frequency.setTargetAtTime(600 + Math.min(Math.abs(speed), 200) * 3, t, 0.1);
    this.updateSkid(handbrake && Math.abs(speed) > 5, t);
  }

  updateSkid(active, t) {
    if (active && !this.skidOn) {
      this.skidOn = true;
      this.skidSource = this.ctx.createBufferSource();
      this.skidSource.buffer = this.noise;
      this.skidSource.loop = true;
      this.skidSource.connect(this.skidFilter);
      this.skidSource.start();
      this.skidGain.gain.setTargetAtTime(0.05, t, 0.05);
    } else if (!active && this.skidOn) {
      this.skidOn = false;
      this.skidGain.gain.setTargetAtTime(0, t, 0.05);
      const s = this.skidSource;
      setTimeout(() => s && s.stop(), 120);
      this.skidSource = null;
    }
  }
}

class Game {
  constructor() {
    this.app = document.getElementById("app");
    this.hudRoot = document.getElementById("hud");
    this.loading = document.getElementById("loading-screen");
    this.loadingBar = document.getElementById("loading-bar");
    this.loadingText = document.getElementById("loading-text");

    this.clock = new THREE.Clock();
    this.fixedDt = 1 / 60;
    this.accum = 0;
    this.started = false;
    this.finished = false;

    this.raceTime = 0;
    this.lapStartTime = 0;
    this.lapTimes = [];
    this.bestLap = Infinity;
    this.currentLap = 1;
    this.currentCheckpoint = 0;

    this.renderer = new THREE.WebGLRenderer({ antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1;
    this.app.insertBefore(this.renderer.domElement, this.loading);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb);
    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);

    this.cameraPos = new THREE.Vector3(0, 10, 20);
    this.cameraLook = new THREE.Vector3();

    this.physics = new World();
    this.physics.gravity.set(0, -9.82, 0);
    this.physics.broadphase = new SAPBroadphase(this.physics);
    this.physics.solver.iterations = 10;

    this.audio = new EngineAudio();

    this.initHud();
    this.initWorld();
    this.initVehicle();
    this.initMinimap();
    this.initParticles();
    this.bindResize();

    this.wakeAudioOnInput = async () => {
      await this.audio.start();
      window.removeEventListener("keydown", this.wakeAudioOnInput);
    };
    window.addEventListener("keydown", this.wakeAudioOnInput);
  }

  initHud() {
    this.hudRoot.innerHTML = `
      <div class="hud-speed-panel">
        <div class="hud-speed-bar" id="speed-bar"></div>
        <div class="hud-speed" id="speed-text">0<span class="hud-speed-unit">km/h</span></div>
      </div>
      <div class="hud-lap" id="lap-text">LAP 1/${TRACK.laps}</div>
      <div class="hud-timer">
        <div id="timer-text">00:00.000</div>
        <div class="hud-lap-time" id="lap-time-text">00:00.000</div>
      </div>
      <div class="hud-controls-hint" id="hint">W/↑ Accel  S/↓ Brake  A/← D/→ Steer  SPACE Handbrake  Q Boost  R Reset</div>
    `;
    this.speedBar = document.getElementById("speed-bar");
    this.speedText = document.getElementById("speed-text");
    this.lapText = document.getElementById("lap-text");
    this.timerText = document.getElementById("timer-text");
    this.lapTimeText = document.getElementById("lap-time-text");
    const hint = document.getElementById("hint");
    setTimeout(() => {
      hint.classList.add("fade-out");
      setTimeout(() => hint.remove(), 900);
    }, 5000);
  }

  initWorld() {
    const sun = new THREE.DirectionalLight(0xffffff, 2);
    sun.position.set(50, 50, 50);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.camera.left = -100;
    sun.shadow.camera.right = 100;
    sun.shadow.camera.top = 100;
    sun.shadow.camera.bottom = -100;
    this.scene.add(sun);
    this.scene.add(new THREE.AmbientLight(0x404040, 0.5));
    this.scene.add(new THREE.HemisphereLight(0x87ceeb, 0x362f27, 0.3));

    const skyGeo = new THREE.SphereGeometry(500, 32, 15);
    const skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      uniforms: {
        topColor: { value: new THREE.Color(0x0077ff) },
        bottomColor: { value: new THREE.Color(0x87ceeb) },
        offset: { value: 33 },
        exponent: { value: 0.6 }
      },
      vertexShader: `varying vec3 vWorldPosition; void main(){ vec4 w = modelMatrix * vec4(position,1.0); vWorldPosition = w.xyz; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `uniform vec3 topColor; uniform vec3 bottomColor; uniform float offset; uniform float exponent; varying vec3 vWorldPosition; void main(){ float h=normalize(vWorldPosition + offset).y; gl_FragColor=vec4(mix(bottomColor, topColor, max(pow(max(h,0.0), exponent), 0.0)),1.0); }`
    });
    this.scene.add(new THREE.Mesh(skyGeo, skyMat));

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(1000, 1000),
      new THREE.MeshStandardMaterial({ color: 0x3a7a2a, roughness: 0.9 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);

    const groundBody = new Body({ mass: 0, shape: new Plane() });
    groundBody.quaternion.setFromEuler(-Math.PI / 2, 0, 0);
    this.physics.addBody(groundBody);

    this.buildTrack();
    this.buildTrees(40);
  }
  buildTrack() {
    const pts = TRACK.spline.map((p) => new THREE.Vector3(p[0], p[1], p[2]));
    this.spline = new THREE.CatmullRomCurve3(pts, true, "catmullrom", 0.5);
    const half = TRACK.width * 0.5;

    const pos = [];
    const uv = [];
    const idx = [];
    for (let i = 0; i <= 200; i++) {
      const t = i / 200;
      const p = this.spline.getPointAt(t);
      const tan = this.spline.getTangentAt(t).normalize();
      const side = new THREE.Vector3().crossVectors(tan, new THREE.Vector3(0, 1, 0)).normalize();
      const l = p.clone().addScaledVector(side, -half);
      const r = p.clone().addScaledVector(side, half);
      l.y += 0.01;
      r.y += 0.01;
      pos.push(l.x, l.y, l.z, r.x, r.y, r.z);
      uv.push(0, t, 1, t);
      if (i < 200) {
        const b = i * 2;
        idx.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();

    const road = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: 0x555555, roughness: 0.8 }));
    road.receiveShadow = true;
    this.scene.add(road);

    try {
      const roadBody = new Body({ mass: 0 });
      roadBody.addShape(new Trimesh(pos, idx));
      this.physics.addBody(roadBody);
    } catch (e) {
      console.warn("Road physics mesh failed; fallback to plane only.", e);
    }

    this.buildGuardrails();
    this.buildLaneMarks();
    this.buildStartLine();
    this.buildCheckpointGates();
  }

  buildGuardrails() {
    const sideOffset = TRACK.width * 0.5 + 0.3;
    const len = 200;
    const unit = 5;
    const count = Math.floor(len / unit);
    const mat = new THREE.MeshStandardMaterial({ color: 0xcccccc });
    for (let i = 0; i < count; i++) {
      const t1 = (i * unit) / len;
      const t2 = ((i + 1) * unit) / len;
      const tm = (t1 + t2) * 0.5;
      const p1 = this.spline.getPointAt(t1);
      const p2 = this.spline.getPointAt(t2);
      const pm = this.spline.getPointAt(tm);
      const tan = this.spline.getTangentAt(tm).normalize();
      const side = new THREE.Vector3().crossVectors(tan, new THREE.Vector3(0, 1, 0)).normalize();
      const segLen = p1.distanceTo(p2);
      const yaw = Math.atan2(tan.x, tan.z);
      for (const sign of [-1, 1]) {
        const c = pm.clone().addScaledVector(side, sign * sideOffset);
        c.y = 0.5;
        const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1, segLen), mat);
        mesh.position.copy(c);
        mesh.rotation.y = yaw;
        mesh.castShadow = true;
        this.scene.add(mesh);

        const body = new Body({ mass: 0 });
        body.addShape(new Box(new Vec3(0.15, 0.5, segLen / 2)));
        body.position.set(c.x, c.y, c.z);
        body.quaternion.setFromEuler(0, yaw, 0);
        this.physics.addBody(body);
      }
    }
  }

  buildLaneMarks() {
    const roadCount = Math.floor(this.spline.getLength() / 8);
    const centerGeo = new THREE.PlaneGeometry(0.3, 2);
    centerGeo.rotateX(-Math.PI / 2);
    const edgeGeo = new THREE.PlaneGeometry(0.2, 1.5);
    edgeGeo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
    const sideDist = TRACK.width * 0.5 - 0.3;

    for (let i = 0; i < roadCount; i++) {
      const t = i / roadCount;
      const p = this.spline.getPointAt(t);
      const tan = this.spline.getTangentAt(t).normalize();
      const yaw = Math.atan2(tan.x, tan.z);
      const side = new THREE.Vector3().crossVectors(tan, new THREE.Vector3(0, 1, 0)).normalize();

      const center = new THREE.Mesh(centerGeo, mat);
      center.position.set(p.x, p.y + 0.02, p.z);
      center.rotation.y = yaw;
      this.scene.add(center);

      const left = new THREE.Mesh(edgeGeo, mat);
      left.position.copy(p.clone().addScaledVector(side, -sideDist));
      left.position.y += 0.02;
      left.rotation.y = yaw;
      this.scene.add(left);

      const right = new THREE.Mesh(edgeGeo, mat);
      right.position.copy(p.clone().addScaledVector(side, sideDist));
      right.position.y += 0.02;
      right.rotation.y = yaw;
      this.scene.add(right);
    }
  }

  buildStartLine() {
    const c = document.createElement("canvas");
    c.width = 128;
    c.height = 32;
    const ctx = c.getContext("2d");
    const cols = 8;
    const rows = 2;
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        ctx.fillStyle = (x + y) % 2 === 0 ? "#fff" : "#111";
        ctx.fillRect((x * c.width) / cols, (y * c.height) / rows, c.width / cols, c.height / rows);
      }
    }

    const line = new THREE.Mesh(
      new THREE.PlaneGeometry(TRACK.width, 2).rotateX(-Math.PI / 2),
      new THREE.MeshStandardMaterial({ map: new THREE.CanvasTexture(c), roughness: 0.6 })
    );
    const p = this.spline.getPointAt(0);
    const tan = this.spline.getTangentAt(0).normalize();
    line.position.set(p.x, p.y + 0.02, p.z);
    line.rotation.y = Math.atan2(tan.x, tan.z);
    this.scene.add(line);
  }

  buildCheckpointGates() {
    const geo = new THREE.PlaneGeometry(1, 3);
    for (const cp of TRACK.checkpoints) {
      const gate = new THREE.Mesh(
        geo,
        new THREE.MeshBasicMaterial({ color: 0x00ff00, transparent: true, opacity: 0.2, side: THREE.DoubleSide, depthWrite: false })
      );
      gate.scale.x = cp.width;
      gate.position.set(cp.position[0], 1.5, cp.position[2]);
      const f = new THREE.Vector3(cp.forward[0], cp.forward[1], cp.forward[2]);
      gate.lookAt(gate.position.clone().add(f));
      this.scene.add(gate);
    }
  }

  buildTrees(count) {
    const trunkGeo = new THREE.CylinderGeometry(0.3, 0.4, 3, 6);
    const crownGeo = new THREE.ConeGeometry(1.8, 8, 6);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x8b5a2b });
    const crownMat = new THREE.MeshStandardMaterial({ color: 0x228b22 });
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const r = 130 + Math.random() * 170;
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.set(x, 1.5, z);
      trunk.castShadow = true;
      this.scene.add(trunk);
      const crown = new THREE.Mesh(crownGeo, crownMat);
      crown.position.set(x, 4, z);
      crown.castShadow = true;
      this.scene.add(crown);
    }
  }

  initVehicle() {
    this.carGroup = new THREE.Group();
    this.chassisGroup = new THREE.Group();

    const base = new THREE.Mesh(new THREE.BoxGeometry(2, 0.4, 4), new THREE.MeshStandardMaterial({ color: 0xff3366 }));
    base.castShadow = true;
    this.chassisGroup.add(base);
    const top = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.35, 2), new THREE.MeshStandardMaterial({ color: 0xcc3355 }));
    top.position.set(0, 0.37, -0.3);
    top.castShadow = true;
    this.chassisGroup.add(top);

    const lightGeo = new THREE.BoxGeometry(0.3, 0.15, 0.1);
    const headMat = new THREE.MeshStandardMaterial({ color: 0xffffcc, emissive: 0xffffcc, emissiveIntensity: 0.8 });
    const tailMat = new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff0000, emissiveIntensity: 0.8 });
    const h1 = new THREE.Mesh(lightGeo, headMat); h1.position.set(-0.65, 0, 2);
    const h2 = new THREE.Mesh(lightGeo, headMat); h2.position.set(0.65, 0, 2);
    const t1 = new THREE.Mesh(lightGeo, tailMat); t1.position.set(-0.65, 0, -2);
    const t2 = new THREE.Mesh(lightGeo, tailMat); t2.position.set(0.65, 0, -2);
    this.chassisGroup.add(h1, h2, t1, t2);

    this.carGroup.add(this.chassisGroup);

    const wheelGeo = new THREE.CylinderGeometry(CAR.wheelRadius, CAR.wheelRadius, 0.3, 16);
    wheelGeo.rotateZ(Math.PI / 2);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x333333 });
    this.wheels = [];
    for (let i = 0; i < 4; i++) {
      const w = new THREE.Mesh(wheelGeo, wheelMat);
      w.castShadow = true;
      this.wheels.push(w);
      this.carGroup.add(w);
    }

    this.scene.add(this.carGroup);

    this.chassisBody = new Body({ mass: CAR.mass, shape: new Box(new Vec3(1, 0.25, 2)) });
    this.chassisBody.position.set(0, 1, 0);
    this.physics.addBody(this.chassisBody);

    this.vehicle = new RaycastVehicle({ chassisBody: this.chassisBody, indexRightAxis: 0, indexUpAxis: 1, indexForwardAxis: 2 });
    const wheelPos = [
      [-0.8, 0, 1.2],
      [0.8, 0, 1.2],
      [-0.8, 0, -1.2],
      [0.8, 0, -1.2]
    ];
    for (const p of wheelPos) {
      this.vehicle.addWheel({
        radius: CAR.wheelRadius,
        suspensionStiffness: CAR.suspensionStiffness,
        dampingCompression: CAR.suspensionDamping,
        dampingRelaxation: CAR.suspensionDamping,
        suspensionRestLength: CAR.suspensionRestLength,
        frictionSlip: CAR.frictionSlip,
        rollInfluence: CAR.rollInfluence,
        directionLocal: new Vec3(0, -1, 0),
        axleLocal: new Vec3(1, 0, 0),
        chassisConnectionPointLocal: new Vec3(p[0], p[1], p[2]),
        maxSuspensionForce: 100000,
        maxSuspensionTravel: 0.3,
        customSlidingRotationalSpeed: -30,
        useCustomSlidingRotationalSpeed: true
      });
    }
    this.vehicle.addToWorld(this.physics);
    this.resetCar();
  }

  resetCar() {
    const p = TRACK.startPosition;
    const q = new Quaternion();
    q.setFromEuler(0, TRACK.startRotation * 0.5, 0);
    this.chassisBody.position.set(p[0], p[1], p[2]);
    this.chassisBody.quaternion.copy(q);
    this.chassisBody.velocity.setZero();
    this.chassisBody.angularVelocity.setZero();
    for (let i = 0; i < 4; i++) {
      this.vehicle.applyEngineForce(0, i);
      this.vehicle.setBrake(0, i);
      this.vehicle.setSteeringValue(0, i);
    }
  }

  initMinimap() {
    this.minimapWrap = document.createElement("div");
    this.minimapWrap.className = "minimap";
    this.minimap = document.createElement("canvas");
    this.minimap.width = 150;
    this.minimap.height = 150;
    this.minimapWrap.appendChild(this.minimap);
    this.hudRoot.appendChild(this.minimapWrap);
    this.mctx = this.minimap.getContext("2d");
    const pad = 10;
    const span = 150 - pad * 2;
    this.mmSpline = TRACK.spline.map((p) => ({ x: ((p[0] + 100) / 200) * span + pad, y: ((p[2] + 100) / 200) * span + pad }));
    this.mmCp = TRACK.checkpoints.map((cp) => ({ x: ((cp.position[0] + 100) / 200) * span + pad, y: ((cp.position[2] + 100) / 200) * span + pad }));
  }
  initParticles() {
    this.dustMax = 100;
    this.dustPos = new Float32Array(this.dustMax * 3);
    this.dustOpacity = new Float32Array(this.dustMax);
    this.dustAlive = Array.from({ length: this.dustMax }, () => ({ alive: false, age: 0, life: 1 }));
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(this.dustPos, 3));
    g.setAttribute("opacity", new THREE.BufferAttribute(this.dustOpacity, 1));
    const m = new THREE.PointsMaterial({ color: 0xcccccc, size: 0.3, transparent: true, opacity: 1, depthWrite: false });
    this.dust = new THREE.Points(g, m);
    this.scene.add(this.dust);
    for (let i = 0; i < this.dustMax; i++) this.dustPos[i * 3 + 1] = -1000;

    this.flameMax = 60;
    this.flamePos = new Float32Array(this.flameMax * 3);
    this.flameColor = new Float32Array(this.flameMax * 3);
    this.flameSize = new Float32Array(this.flameMax);
    this.flameAge = new Float32Array(this.flameMax);
    this.flameAlive = new Array(this.flameMax).fill(false);
    this.flameVel = Array.from({ length: this.flameMax }, () => new THREE.Vector3());

    const fg = new THREE.BufferGeometry();
    fg.setAttribute("position", new THREE.BufferAttribute(this.flamePos, 3));
    fg.setAttribute("color", new THREE.BufferAttribute(this.flameColor, 3));
    fg.setAttribute("size", new THREE.BufferAttribute(this.flameSize, 1));
    const fm = new THREE.PointsMaterial({ size: 0.5, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending, vertexColors: true });
    this.flame = new THREE.Points(fg, fm);
    this.scene.add(this.flame);
    for (let i = 0; i < this.flameMax; i++) this.flamePos[i * 3 + 1] = -1000;
  }

  updateDust(dt, speed, p) {
    for (let i = 0; i < this.dustMax; i++) {
      const d = this.dustAlive[i];
      if (!d.alive) continue;
      d.age += dt;
      if (d.age > d.life) {
        d.alive = false;
        this.dustPos[i * 3 + 1] = -1000;
        this.dustOpacity[i] = 0;
        continue;
      }
      this.dustPos[i * 3 + 1] += 0.5 * dt;
      this.dustOpacity[i] = 1 - d.age / d.life;
    }

    if (Math.abs(speed) > 30) {
      let add = Math.min(3, Math.floor(Math.abs(speed) / 30));
      for (let i = 0; i < this.dustMax && add > 0; i++) {
        const d = this.dustAlive[i];
        if (d.alive) continue;
        d.alive = true;
        d.age = 0;
        d.life = 0.8 + Math.random() * 0.4;
        this.dustPos[i * 3] = p.x + (Math.random() - 0.5) * 1.5;
        this.dustPos[i * 3 + 1] = p.y + 0.1;
        this.dustPos[i * 3 + 2] = p.z + (Math.random() - 0.5) * 1.5;
        this.dustOpacity[i] = 1;
        add--;
      }
    }

    this.dust.geometry.attributes.position.needsUpdate = true;
  }

  updateFlame(dt, pos, quat, boosting) {
    for (let i = 0; i < this.flameMax; i++) {
      if (!this.flameAlive[i]) continue;
      this.flameAge[i] += dt;
      const life = 0.35;
      if (this.flameAge[i] > life) {
        this.flameAlive[i] = false;
        this.flamePos[i * 3 + 1] = -1000;
        this.flameSize[i] = 0;
        continue;
      }
      const t = this.flameAge[i] / life;
      this.flamePos[i * 3] += this.flameVel[i].x * dt;
      this.flamePos[i * 3 + 1] += this.flameVel[i].y * dt + dt * 2;
      this.flamePos[i * 3 + 2] += this.flameVel[i].z * dt;
      this.flameSize[i] = (1 - t) * 0.5;
      const c = t < 0.5 ? [1, 0.7, 0.1] : [0.8 * (1 - t), 0.1 * (1 - t), 0];
      this.flameColor[i * 3] = c[0];
      this.flameColor[i * 3 + 1] = c[1];
      this.flameColor[i * 3 + 2] = c[2];
    }

    if (boosting) {
      const local = [new THREE.Vector3(-0.4, -0.1, -2.2), new THREE.Vector3(0.4, -0.1, -2.2)];
      const backward = new THREE.Vector3(0, 0, -1).applyQuaternion(quat);
      for (const l of local) {
        const world = pos.clone().add(l.clone().applyQuaternion(quat));
        const n = 2 + Math.floor(Math.random() * 2);
        for (let k = 0; k < n; k++) {
          const i = this.flameAlive.findIndex((v) => !v);
          if (i === -1) break;
          this.flameAlive[i] = true;
          this.flameAge[i] = 0;
          this.flamePos[i * 3] = world.x + (Math.random() - 0.5) * 0.2;
          this.flamePos[i * 3 + 1] = world.y + (Math.random() - 0.5) * 0.1;
          this.flamePos[i * 3 + 2] = world.z + (Math.random() - 0.5) * 0.2;
          this.flameVel[i].set(backward.x * (8 + Math.random() * 4), Math.random() * 2, backward.z * (8 + Math.random() * 4));
          this.flameSize[i] = 0.4;
        }
      }
    }

    this.flame.geometry.attributes.position.needsUpdate = true;
    this.flame.geometry.attributes.color.needsUpdate = true;
    this.flame.geometry.attributes.size.needsUpdate = true;
  }

  applyInput() {
    const i = inputState();
    const steer = -i.steer * CAR.maxSteerAngle;
    this.vehicle.setSteeringValue(steer, 0);
    this.vehicle.setSteeringValue(steer, 1);

    const power = i.boost ? 5 : 1;
    const engine = ((i.brake ? 1 : 0) - (i.accelerate ? 1 : 0)) * CAR.maxEngineForce * power;
    this.vehicle.applyEngineForce(engine, 2);
    this.vehicle.applyEngineForce(engine, 3);

    for (let w = 0; w < 4; w++) this.vehicle.setBrake(0, w);
    if (i.handbrake) {
      this.vehicle.setBrake(CAR.maxBrakeForce * 2, 2);
      this.vehicle.setBrake(CAR.maxBrakeForce * 2, 3);
    }

    if (i.resetCar) this.resetCar();
    return i;
  }

  getSpeed() {
    const v = this.chassisBody.velocity;
    const forward = new Vec3(0, 0, 1);
    this.chassisBody.quaternion.vmult(forward, forward);
    return -v.dot(forward) * 3.6;
  }

  syncCarVisual() {
    const p = this.chassisBody.position;
    const q = this.chassisBody.quaternion;
    this.chassisGroup.position.set(p.x, p.y, p.z);
    this.chassisGroup.quaternion.set(q.x, q.y, q.z, q.w);

    for (let i = 0; i < 4; i++) {
      this.vehicle.updateWheelTransform(i);
      const wt = this.vehicle.wheelInfos[i].worldTransform;
      this.wheels[i].position.set(wt.position.x, wt.position.y, wt.position.z);
      this.wheels[i].quaternion.set(wt.quaternion.x, wt.quaternion.y, wt.quaternion.z, wt.quaternion.w);
    }
  }

  updateCamera(dt, speed) {
    const target = this.chassisGroup.position.clone();
    const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(this.chassisGroup.quaternion);
    const back = forward.clone().negate();

    const desiredPos = target.clone().addScaledVector(back, CAR.cameraFollow.distance);
    desiredPos.y = target.y + CAR.cameraFollow.height;
    const desiredLook = target.clone().addScaledVector(forward, CAR.cameraFollow.lookAhead);

    const a = 1 - Math.exp(-5 * dt);
    this.cameraPos.lerp(desiredPos, a);
    this.cameraLook.lerp(desiredLook, a);

    const maxFov = 75;
    const baseFov = 60;
    const vfov = baseFov + (maxFov - baseFov) * Math.min(Math.abs(speed) / 200, 1);
    this.camera.fov += (vfov - this.camera.fov) * a;
    this.camera.updateProjectionMatrix();

    this.camera.position.copy(this.cameraPos);
    this.camera.lookAt(this.cameraLook);
  }
  updateRace(dt) {
    if (!this.started || this.finished) return;
    this.raceTime += dt;
    const cp = TRACK.checkpoints[this.currentCheckpoint];
    const p = this.chassisGroup.position;
    const dx = p.x - cp.position[0];
    const dy = p.y - cp.position[1];
    const dz = p.z - cp.position[2];
    if (Math.sqrt(dx * dx + dy * dy + dz * dz) < 5) {
      this.currentCheckpoint++;
      if (this.currentCheckpoint >= TRACK.checkpoints.length) {
        this.currentCheckpoint = 0;
        const lap = this.raceTime - this.lapStartTime;
        this.lapTimes.push(lap);
        this.bestLap = Math.min(this.bestLap, lap);
        this.lapStartTime = this.raceTime;
        if (this.currentLap >= TRACK.laps) {
          this.finished = true;
          this.started = false;
          this.showResult();
        } else {
          this.currentLap++;
          this.showLapNotice();
        }
      }
    }
  }

  updateHud(speed) {
    const s = Math.round(Math.abs(speed));
    this.speedText.innerHTML = `${s}<span class="hud-speed-unit">km/h</span>`;
    this.speedBar.style.width = `${Math.min((s / 250) * 200, 200)}px`;
    this.speedBar.style.background = s < 80 ? "#00ff88" : s < 160 ? "#ffaa00" : "#ff4444";
    this.lapText.textContent = `LAP ${this.currentLap}/${TRACK.laps}`;
    this.timerText.textContent = formatMs(this.raceTime * 1000);
    const passed = this.lapTimes.reduce((a, b) => a + b, 0);
    this.lapTimeText.textContent = formatMs((this.raceTime - passed) * 1000);
  }

  updateMinimap() {
    const c = this.mctx;
    c.clearRect(0, 0, 150, 150);
    c.strokeStyle = "rgba(255,255,255,.4)";
    c.lineWidth = 2;
    c.beginPath();
    c.moveTo(this.mmSpline[0].x, this.mmSpline[0].y);
    for (let i = 1; i < this.mmSpline.length; i++) c.lineTo(this.mmSpline[i].x, this.mmSpline[i].y);
    c.closePath();
    c.stroke();

    c.fillStyle = "#00ff88";
    for (const p of this.mmCp) {
      c.beginPath();
      c.arc(p.x, p.y, 3, 0, Math.PI * 2);
      c.fill();
    }

    const x = ((this.chassisGroup.position.x + 100) / 200) * 130 + 10;
    const y = ((this.chassisGroup.position.z + 100) / 200) * 130 + 10;
    c.fillStyle = "#ff4444";
    c.beginPath();
    c.arc(x, y, 4, 0, Math.PI * 2);
    c.fill();
  }

  showLapNotice() {
    const e = document.createElement("div");
    e.className = "lap-notification";
    e.textContent = `LAP ${this.currentLap}/${TRACK.laps}`;
    this.hudRoot.appendChild(e);
    setTimeout(() => e.remove(), 2200);
  }

  showResult() {
    const wrap = document.createElement("div");
    wrap.className = "result-overlay";
    wrap.innerHTML = `
      <div class="result-panel">
        <div class="result-title">RACE COMPLETE</div>
        <div class="result-total-time">${formatMs(this.raceTime * 1000)}</div>
        <div class="result-best-lap">Best Lap: ${formatMs(this.bestLap * 1000)}</div>
        <ul class="result-lap-list">
          ${this.lapTimes.map((t, i) => `<li class="${t === this.bestLap ? "best" : ""}"><span>Lap ${i + 1}</span><span>${formatMs(t * 1000)}</span></li>`).join("")}
        </ul>
        <button class="result-restart-btn" id="retry-btn">RETRY</button>
      </div>
    `;
    this.app.appendChild(wrap);
    wrap.querySelector("#retry-btn").addEventListener("click", () => {
      wrap.remove();
      this.restart();
    });
  }

  async runCountdown() {
    const overlay = document.createElement("div");
    overlay.className = "countdown-overlay";
    this.app.appendChild(overlay);
    for (const text of ["3", "2", "1", "GO!"]) {
      overlay.innerHTML = `<span class="countdown-text">${text}</span>`;
      await new Promise((r) => setTimeout(r, 1000));
    }
    overlay.remove();
  }

  bindResize() {
    window.addEventListener("resize", () => {
      this.renderer.setSize(window.innerWidth, window.innerHeight);
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
    });
  }

  async start() {
    this.loadingText.textContent = "Preparing scene...";
    this.loadingBar.style.width = "35%";
    await new Promise((r) => setTimeout(r, 120));
    this.loadingText.textContent = "Building race systems...";
    this.loadingBar.style.width = "80%";
    await new Promise((r) => setTimeout(r, 120));
    this.loadingBar.style.width = "100%";
    this.loading.style.opacity = "0";
    setTimeout(() => (this.loading.style.display = "none"), 500);

    await this.runCountdown();
    this.started = true;
    this.loop();
  }

  restart() {
    this.finished = false;
    this.started = false;
    this.raceTime = 0;
    this.lapStartTime = 0;
    this.lapTimes = [];
    this.bestLap = Infinity;
    this.currentLap = 1;
    this.currentCheckpoint = 0;
    this.resetCar();
    this.runCountdown().then(() => {
      this.started = true;
    });
  }

  loop = () => {
    requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.1);

    const input = this.applyInput();
    this.accum += dt;
    while (this.accum >= this.fixedDt) {
      this.physics.step(this.fixedDt);
      this.accum -= this.fixedDt;
    }

    this.syncCarVisual();
    const speed = this.getSpeed();
    this.updateRace(dt);
    this.updateHud(speed);
    this.updateMinimap();
    this.updateDust(dt, speed, this.chassisGroup.position);
    this.updateFlame(dt, this.chassisGroup.position, this.chassisGroup.quaternion, this.started && input.boost);
    this.audio.update(speed, input.accelerate, input.handbrake);
    this.updateCamera(dt, this.started && input.boost ? Math.max(Math.abs(speed), 180) : speed);

    this.renderer.render(this.scene, this.camera);
  };
}

const loadingTextEl = document.getElementById("loading-text");
const loadingBarEl = document.getElementById("loading-bar");

try {
  const game = new Game();
  game.start().catch((err) => {
    console.error(err);
    if (loadingBarEl) loadingBarEl.style.width = "100%";
    if (loadingTextEl) loadingTextEl.textContent = `Error: ${err?.message || "init failed"}`;
  });
} catch (err) {
  console.error(err);
  if (loadingBarEl) loadingBarEl.style.width = "100%";
  if (loadingTextEl) loadingTextEl.textContent = `Error: ${err?.message || "init failed"}`;
}
